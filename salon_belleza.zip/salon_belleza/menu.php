<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f9;
        }
        header {
            background-color: #eaa8f0;
            color: white;
            padding: 15px;
            text-align: center;
        }
        nav {
            background-color: #333;
            overflow: hidden;
            display: flex;
            justify-content: center;
        }
        nav a {
            padding: 14px 20px;
            display: block;
            color: white;
            text-decoration: none;
            text-align: center;
        }
        nav a:hover {
            background-color: #eaa8f0;
        }
        .container {
            margin-top: 20px;
            padding: 20px;
        }
    </style>
</head>
<body>
    <header>
        <h1>Sistema para Control de Salón de Belleza</h1>
    </header>
    <nav>
        <a href="/salon_belleza/">Inicio</a>
        <a href="/salon_belleza/clientes/listar.php">Gestión de Clientes</a>
        <a href="/salon_belleza/citas/listar_citas.php">Gestión de Citas</a>
        <a href="/salon_belleza/servicios/listar_servicios.php">Gestión de Servicios</a>
        <a href="/salon_belleza/empleados/listar_empleado.php">Gestión de Empleados</a>
        <a href="/salon_belleza/pagos/listar_pagos.php">Gestiones de Pagos</a>
    </nav>
</body>
</html>