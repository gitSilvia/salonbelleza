<?php
include '../db.php'; // Conexión a la base de datos

if (isset($_GET['id'])) {
    $id_empleado = $_GET['id'];

    // Eliminar el empleado de la base de datos
    $sql = "DELETE FROM empleados WHERE id_empleado = $id_empleado";

    if ($conn->query($sql) === TRUE) {
        header('Location: listar_empleado.php'); // Redirige a la lista de empleados después de eliminar
    } else {
        echo "Error al eliminar el empleado: " . $conn->error;
    }
}
?>
