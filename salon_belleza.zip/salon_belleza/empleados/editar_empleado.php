<?php
include '../db.php'; // Conexión a la base de datos
include '../menu.php'; // Menú fijo

// Verificar si el parámetro id_empleado está en la URL
if (isset($_GET['id_empleado'])) {
    $id_empleado = $_GET['id_empleado'];

    // Consultar los datos del empleado a editar
    $sql = "SELECT * FROM empleados WHERE id_empleado = $id_empleado";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
    } else {
        echo "Empleado no encontrado.";
        exit;
    }
} else {
    echo "No se especificó el empleado.";
    exit;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nombre = $_POST['nombre'];
    $rol = $_POST['rol'];
    $telefono = $_POST['telefono'];

    $sql = "UPDATE empleados SET nombre = '$nombre', rol = '$rol', telefono = '$telefono' WHERE id_empleado = $id_empleado";

    if ($conn->query($sql) === TRUE) {
        header('Location: listar_empleado.php'); // Redirige a la lista de empleados después de actualizar
        exit;
    } else {
        echo "Error al actualizar el empleado: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Empleado</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>

    <div class="form-container">
        <h1>Editar Empleado</h1>
        <form method="POST">
            <label for="nombre">Nombre:</label>
            <input type="text" name="nombre" value="<?php echo $row['nombre']; ?>" required>
            <label for="rol">Rol:</label>
            <input type="text" name="rol" value="<?php echo $row['rol']; ?>" required>
            <label for="telefono">Teléfono:</label>
            <input type="tel" name="telefono" value="<?php echo $row['telefono']; ?>" required>
            <button type="submit" class="submit-button">Actualizar</button>
        </form>
    </div>

</body>
</html>
