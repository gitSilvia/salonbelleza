<?php
include '../db.php'; // Conexión a la base de datos
include '../menu.php'; // Menú fijo
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión de Empleados</title>
    <link rel="stylesheet" href="../css/style.css"> <!-- Enlace al archivo de estilos CSS -->
</head>
<body>
    <div class="container">
        <h1>Gestión de Empleados</h1>
        <a href="agregar_empleado.php" class="add-button">Agregar Empleado</a>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nombre</th>
                    <th>Rol</th>
                    <th>Teléfono</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $sql = "SELECT * FROM empleados";
                $result = $conn->query($sql);

                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr>";
                        echo "<td>" . $row['id_empleado'] . "</td>";
                        echo "<td>" . $row['nombre'] . "</td>";
                        echo "<td>" . $row['rol'] . "</td>";
                        echo "<td>" . $row['telefono'] . "</td>";
                        echo "<td>";
                        echo "<a href='editar_empleado.php?id_empleado=" . $row['id_empleado'] . "'>Editar</a> | ";
                        echo "<a href='#' onclick='openModal(" . $row['id_empleado'] . ")'>Eliminar</a>";
                        echo "</td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='5'>No hay empleados registrados.</td></tr>";
                }
                ?>
            </tbody>
        </table>
    </div>

    <!-- Modal de Confirmación -->
    <div id="confirmationModal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closeModal()">&times;</span>
            <h2>¿Estás seguro de eliminar este empleado?</h2>
            <p id="modalMessage"></p>
            <button id="confirmDelete" class="btn-confirm">Sí</button>
            <button class="btn-cancel" onclick="closeModal()">No</button>
        </div>
    </div>

    <script>
        let empleadoIdToDelete = null;

        function openModal(empleadoId) {
            empleadoIdToDelete = empleadoId;
            document.getElementById("modalMessage").innerHTML = "Esta acción no se puede deshacer.";
            document.getElementById("confirmationModal").style.display = "block";
        }

        function closeModal() {
            document.getElementById("confirmationModal").style.display = "none";
        }

        document.getElementById("confirmDelete").onclick = function() {
            if (empleadoIdToDelete !== null) {
                window.location.href = "eliminar_empleado.php?id=" + empleadoIdToDelete;
            }
        }
    </script>
</body>
</html>
