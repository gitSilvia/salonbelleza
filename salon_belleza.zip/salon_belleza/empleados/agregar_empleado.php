<?php
include '../db.php'; // Conexión a la base de datos
include '../menu.php'; // Menú fijo

// Guardar el nuevo empleado al enviar el formulario
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nombre = $_POST['nombre'];
    $rol = $_POST['rol'];
    $telefono = $_POST['telefono'];

    $sql = "INSERT INTO empleados (nombre, rol, telefono) VALUES ('$nombre', '$rol', '$telefono')";
    if ($conn->query($sql) === TRUE) {
        header('Location: listar_empleado.php'); // Redirige a la lista de empleados
        exit;
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agregar Empleado</title>
    <!-- Enlace al archivo CSS -->
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <div class="form-container">
        <h1>Agregar Empleado</h1>
        <form method="POST" action="">
            <label for="nombre">Nombre</label>
            <input type="text" name="nombre" id="nombre" required>

            <label for="rol">Rol</label>
            <input type="text" name="rol" id="rol" required>

            <label for="telefono">Teléfono</label>
            <input type="text" name="telefono" id="telefono" required>

            <button type="submit">Agregar Empleado</button>
        </form>
    </div>
</body>
</html>
