<?php 
include '../db.php'; // Conexión a la base de datos
include '../menu.php'; // Menú fijo

// Guardar el nuevo cliente al enviar el formulario
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nombre = $_POST['nombre'];
    $telefono = $_POST['telefono'];
    $email = $_POST['email'];

    // Insertar el cliente en la base de datos
    $sql = "INSERT INTO clientes (nombre, telefono, email) VALUES ('$nombre', '$telefono', '$email')";
    if ($conn->query($sql) === TRUE) {
        header('Location: listar.php'); // Redirige a la lista de clientes
        exit;
    } else {
        echo "Error: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agregar Cliente</title>
    <link rel="stylesheet" href="../css/style.css"> <!-- Referencia al archivo CSS -->
</head>
<body>
    <div class="container">
        <h1>Agregar Cliente</h1>
        <form method="POST" action="">
            <label for="nombre">Nombre:</label>
            <input type="text" id="nombre" name="nombre" required>

            <label for="telefono">Teléfono:</label>
            <input type="text" id="telefono" name="telefono" required>

            <label for="email">Email:</label>
            <input type="email" id="email" name="email" required>

            <button type="submit" name="submit">Agregar Cliente</button>
        </form>
    </div>
</body>
</html>
