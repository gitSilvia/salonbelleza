<?php
include '../db.php'; // Conexión a la base de datos

if (isset($_GET['id'])) {
    $id_cliente = $_GET['id'];

    // Eliminar la cita de la base de datos
    $sql = "DELETE FROM clientes WHERE id_cliente = $id_cliente";

    if ($conn->query($sql) === TRUE) {
        header('Location: listar.php'); // Redirige después de eliminar
    } else {
        echo "Error al eliminar la cita: " . $conn->error;
    }
}
?>