<?php
include '../db.php'; // Conexión a la base de datos
include '../menu.php'; // Menú fijo

// Verificar si se ha pasado un ID en la URL
if (!isset($_GET['id']) || empty($_GET['id'])) {
    echo "<script>alert('ID de cliente no especificado.'); window.location.href = 'listar.php';</script>";
    exit();
}

$id_cliente = $_GET['id'];

// Obtener los datos actuales del cliente
$sql = "SELECT * FROM clientes WHERE id_cliente = $id_cliente";
$result = $conn->query($sql);

if ($result->num_rows == 0) {
    echo "<script>alert('Cliente no encontrado.'); window.location.href = 'listar.php';</script>";
    exit();
}

$cliente = $result->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Cliente</title>
    <link rel="stylesheet" href="../css/style.css"> <!-- Se enlaza el archivo de CSS -->
</head>
<body>
    <div class="container">
        <h1>Editar Cliente</h1>
        <form method="POST" action="">
            <label for="nombre">Nombre:</label>
            <input type="text" id="nombre" name="nombre" value="<?php echo $cliente['nombre']; ?>" required>
            
            <label for="telefono">Teléfono:</label>
            <input type="text" id="telefono" name="telefono" value="<?php echo $cliente['telefono']; ?>" required>
            
            <label for="email">Email:</label>
            <input type="email" id="email" name="email" value="<?php echo $cliente['email']; ?>" required>
            
            <button type="submit" name="submit">Actualizar Cliente</button>
        </form>
    </div>

    <?php
    // Procesar la actualización
    if (isset($_POST['submit'])) {
        $nombre = $_POST['nombre'];
        $telefono = $_POST['telefono'];
        $email = $_POST['email'];

        $sql = "UPDATE clientes SET nombre='$nombre', telefono='$telefono', email='$email' WHERE id_cliente=$id_cliente";

        if ($conn->query($sql) === TRUE) {
            header('Location: listar.php');
            exit;
        } else {
            echo "Error: " . $conn->error;
        }
    }
    ?>
</body>
</html>
