<?php 
include '../db.php'; // Conexión a la base de datos
include '../menu.php'; // Menú fijo
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión de Clientes</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <div class="container">
        <h1>Gestión de Clientes</h1>
        <a href="agregar.php" class="add-button">Agregar Cliente</a>
        <link rel="stylesheet" href="../css/style.css">
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nombre</th>
                    <th>Teléfono</th>
                    <th>Email</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php
                // Consultar los clientes de la base de datos
                $sql = "SELECT * FROM clientes";
                $result = $conn->query($sql);

                if ($result->num_rows > 0) {
                    // Mostrar cada cliente en una fila
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr>";
                        echo "<td>" . $row['id_cliente'] . "</td>";
                        echo "<td>" . $row['nombre'] . "</td>";
                        echo "<td>" . $row['telefono'] . "</td>";
                        echo "<td>" . $row['email'] . "</td>";
                        echo "<td>";
                        echo "<a href='editar.php?id=" . $row['id_cliente'] . "'>Editar</a> | ";
                        echo "<a href='#' onclick='openModal(" . $row['id_cliente'] . ")'>Eliminar</a>";
                        echo "</td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='5'>No hay clientes registrados.</td></tr>";
                }
                ?>
            </tbody>
        </table>
    </div>

    <!-- Modal de confirmación de eliminación -->
    <div id="confirmationModal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closeModal()">&times;</span>
            <h2>¿Estás seguro de eliminar este cliente?</h2>
            <p id="modalMessage">Esta acción no se puede deshacer.</p>
            <button id="confirmDelete" class="btn-confirm">Sí</button>
            <button class="btn-cancel" onclick="closeModal()">No</button>
        </div>
    </div>

    <script>
        var clientIdToDelete = null;

        // Función para abrir el modal y pasar el ID del cliente
        function openModal(clientId) {
            clientIdToDelete = clientId;
            document.getElementById("modalMessage").innerHTML = "Esta acción no se puede deshacer.";
            document.getElementById("confirmationModal").style.display = "block";
        }

        // Función para cerrar el modal
        function closeModal() {
            document.getElementById("confirmationModal").style.display = "none";
        }

        // Cuando el usuario haga clic en "Sí", eliminar el cliente
        document.getElementById("confirmDelete").onclick = function() {
            if (clientIdToDelete !== null) {
                window.location.href = "eliminar.php?id=" + clientIdToDelete;
            }
        }
    </script>
</body>
</html>
