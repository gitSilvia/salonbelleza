<div id="carouselExampleControls" class="carousel slide" data-bs-ride="carousel">
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="imagen/imagen02.png" class="d-block w-100" alt="Imagen">
    </div>
    </div>
    </div>

