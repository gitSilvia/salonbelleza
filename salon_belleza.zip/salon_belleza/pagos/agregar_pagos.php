<?php
include '../db.php'; // Conexión a la base de datos
include '../menu.php'; // Menú fijo

// Guardar el nuevo pago al enviar el formulario
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id_cita = $_POST['id_cita'];
    $monto_pagado = $_POST['monto_pagado'];
    $fecha_pago = $_POST['fecha_pago'];

    $sql = "INSERT INTO pagos (id_cita, monto_pagado, fecha_pago) 
            VALUES ('$id_cita', '$monto_pagado', '$fecha_pago')";

    if ($conn->query($sql) === TRUE) {
        header('Location: listar_pagos.php'); // Redirige a la lista de pagos
        exit;
    } else {
        echo "Error: " . $conn->error;
    }
}

// Consulta para obtener la lista de citas con información adicional
$citas = $conn->query("
    SELECT 
        c.id_cita, 
        cl.nombre AS cliente, 
        c.monto_total 
    FROM citas c
    JOIN clientes cl ON c.id_cliente = cl.id_cliente
    WHERE c.id_cita NOT IN (SELECT id_cita FROM pagos)
");
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agregar Pago</title>
    <!-- Enlace al archivo CSS -->
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <div class="form-container">
        <h1>Agregar Pago</h1>
        <form method="POST" action="">
            <label for="id_cita">Cita</label>
            <select name="id_cita" id="id_cita" required>
                <option value="">Seleccione una cita</option>
                <?php while ($cita = $citas->fetch_assoc()): ?>
                    <option value="<?php echo $cita['id_cita']; ?>">
                        <?php echo "Cliente: " . $cita['cliente'] . " - Monto a Pagar: $" . $cita['monto_total']; ?>
                    </option>
                <?php endwhile; ?>
            </select>

            <label for="monto_pagado">Monto Pagado</label>
            <input type="number" name="monto_pagado" id="monto_pagado" step="0.01" required>

            <label for="fecha_pago">Fecha de Pago</label>
            <input type="date" name="fecha_pago" id="fecha_pago" required>

            <button type="submit">Registrar Pago</button>
        </form>
    </div>
</body>
</html>
