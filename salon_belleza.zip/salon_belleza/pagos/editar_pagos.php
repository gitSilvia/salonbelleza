<?php
include '../db.php'; // Conexión a la base de datos
include '../menu.php'; // Menú fijo

// Verificar si se recibe un ID para editar
if (isset($_GET['id'])) {
    $id_pago = $_GET['id'];

    // Consultar los datos del pago a editar
    $sql = "
        SELECT 
            p.id_pago, 
            p.monto_pagado, 
            p.fecha_pago, 
            cl.nombre AS cliente, 
            c.monto_total 
        FROM pagos p
        JOIN citas c ON p.id_cita = c.id_cita
        JOIN clientes cl ON c.id_cliente = cl.id_cliente
        WHERE p.id_pago = $id_pago
    ";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $pago = $result->fetch_assoc();
    } else {
        echo "<script>alert('Pago no encontrado'); window.location.href = 'listar_pagos.php';</script>";
        exit;
    }
}

// Guardar los cambios al enviar el formulario
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $monto_pagado = $_POST['monto_pagado'];
    $fecha_pago = $_POST['fecha_pago'];

    $sql = "
        UPDATE pagos 
        SET monto_pagado = '$monto_pagado', fecha_pago = '$fecha_pago' 
        WHERE id_pago = $id_pago
    ";

    if ($conn->query($sql) === TRUE) {
        header('Location: listar_pagos.php'); // Redirige a la lista de pagos
        exit;
    } else {
        echo "Error: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Pago</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <div class="form-container">
        <h1>Editar Pago</h1>
        <form method="POST" action="">
            <label for="cliente">Cliente</label>
            <input type="text" id="cliente" value="<?php echo $pago['cliente']; ?>" disabled>

            <label for="monto_total">Monto Total</label>
            <input type="text" id="monto_total" value="<?php echo $pago['monto_total']; ?>" disabled>

            <label for="monto_pagado">Monto Pagado</label>
            <input type="number" name="monto_pagado" id="monto_pagado" value="<?php echo $pago['monto_pagado']; ?>" step="0.01" required>

            <label for="fecha_pago">Fecha de Pago</label>
            <input type="date" name="fecha_pago" id="fecha_pago" value="<?php echo $pago['fecha_pago']; ?>" required>

            <button type="submit">Actualizar Pago</button>
        </form>
    </div>
</body>
</html>
