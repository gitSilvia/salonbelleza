<?php 
include '../db.php'; // Conexión a la base de datos

// Verificar si se recibe un ID para eliminar
if (isset($_GET['id'])) {
    $id_pago = $_GET['id'];

    // Eliminar el pago de la base de datos
    $sql = "DELETE FROM pagos WHERE id_pago = $id_pago";

    if ($conn->query($sql) === TRUE) {
        header('Location: listar_pagos.php'); // Redirige a la lista de pagos después de eliminar
        exit;
    } else {
        echo "Error al eliminar el pago: " . $conn->error;
    }
} else {
    echo "<script>alert('No se especificó el pago'); window.location.href = 'listar_pagos.php';</script>";
    exit;
}
?>
