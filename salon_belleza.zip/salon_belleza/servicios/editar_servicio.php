<?php
include '../db.php'; // Conexión a la base de datos
include '../menu.php'; // Menú fijo

// Verificar si se recibe un ID para editar
if (isset($_GET['id'])) {
    $id_servicio = $_GET['id'];

    // Consultar los datos del servicio a editar
    $sql = "SELECT * FROM servicios WHERE id_servicio = $id_servicio";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $servicio = $result->fetch_assoc();
    } else {
        echo "<script>alert('Servicio no encontrado'); window.location.href = 'listar_servicios.php';</script>";
        exit;
    }
}

// Guardar los cambios al enviar el formulario
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nombre_servicio = $_POST['nombre_servicio'];
    $descripcion = $_POST['descripcion'];
    $precio = $_POST['precio'];

    $sql = "UPDATE servicios SET nombre_servicio = '$nombre_servicio', descripcion = '$descripcion', precio = '$precio' WHERE id_servicio = $id_servicio";

    if ($conn->query($sql) === TRUE) {
        header('Location: listar_servicios.php'); // Redirige a la lista de servicios
        exit;
    } else {
        echo "Error: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Servicio</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <div class="form-container">
        <h1>Editar Servicio</h1>
        <form method="POST" action="">
            <label for="nombre_servicio">Nombre del Servicio</label>
            <input type="text" name="nombre_servicio" id="nombre_servicio" value="<?php echo $servicio['nombre_servicio']; ?>" required>

            <label for="descripcion">Descripción</label>
            <textarea name="descripcion" id="descripcion" rows="4" required><?php echo $servicio['descripcion']; ?></textarea>

            <label for="precio">Precio</label>
            <input type="number" step="0.01" name="precio" id="precio" value="<?php echo $servicio['precio']; ?>" required>

            <button type="submit">Actualizar Servicio</button>
        </form>
    </div>
</body>
</html>
