<?php
include '../db.php'; // Conexión a la base de datos

// Verificar si se recibe un ID para eliminar
if (isset($_GET['id'])) {
    $id_servicio = $_GET['id'];

    // Eliminar el servicio de la base de datos
    $sql = "DELETE FROM servicios WHERE id_servicio = $id_servicio";

    if ($conn->query($sql) === TRUE) {
        header('Location: listar_servicios.php'); // Redirige a la lista de servicios después de eliminar
        exit;
    } else {
        echo "Error al eliminar el servicio: " . $conn->error;
    }
} else {
    echo "<script>alert('No se especificó el servicio'); window.location.href = 'listar_servicios.php';</script>";
    exit;
}
?>
