<?php
include '../db.php'; // Conexión a la base de datos
include '../menu.php'; // Menú fijo

// Guardar el servicio cuando se envíe el formulario
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nombre_servicio = $_POST['nombre_servicio'];
    $descripcion = $_POST['descripcion'];
    $precio = $_POST['precio'];

    $sql = "INSERT INTO servicios (nombre_servicio, descripcion, precio) VALUES ('$nombre_servicio', '$descripcion', '$precio')";

    if ($conn->query($sql) === TRUE) {
        header('Location: listar_servicios.php');  
        exit;
     } else {
        echo "Error: " . $sql . "<br>" . $conn->error;    }
    
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agregar Servicio</title>
    <!-- Enlace al archivo CSS -->
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <div class="form-container">
        <h1>Agregar Servicio</h1>
        <form method="POST" action="">
            <label for="nombre_servicio">Nombre del Servicio</label>
            <input type="text" name="nombre_servicio" id="nombre_servicio" required>

            <label for="descripcion">Descripción</label>
            <textarea name="descripcion" id="descripcion" rows="4" required></textarea>

            <label for="precio">Precio</label>
            <input type="number" name="precio" id="precio" step="0.01" required>

            <button type="submit">Agregar Servicio</button>
        </form>
    </div>
</body>
</html>
