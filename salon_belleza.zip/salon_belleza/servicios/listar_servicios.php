<?php
include '../db.php'; // Conexión a la base de datos
include '../menu.php'; // Menú fijo
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión de Servicios</title>
    <link rel="stylesheet" href="../css/style.css"> <!-- Enlace al archivo de estilos CSS -->
</head>
<body>
    <div class="container">
        <h1>Gestión de Servicios</h1>
        <a href="agregar_servicio.php" class="add-button">Agregar Servicio</a>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nombre</th>
                    <th>Descripción</th>
                    <th>Precio</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php
                // Consultar los servicios de la base de datos
                $sql = "SELECT * FROM servicios";
                $result = $conn->query($sql);

                if ($result->num_rows > 0) {
                    // Mostrar cada servicio en una fila
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr>";
                        echo "<td>" . $row['id_servicio'] . "</td>";
                        echo "<td>" . $row['nombre_servicio'] . "</td>";
                        echo "<td>" . $row['descripcion'] . "</td>";
                        echo "<td>$" . $row['precio'] . "</td>";
                        echo "<td>";
                        echo "<a href='editar_servicio.php?id=" . $row['id_servicio'] . "'>Editar</a> | ";
                        echo "<a href='#' onclick='openModal(" . $row['id_servicio'] . ")'>Eliminar</a>";
                        echo "</td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='5'>No hay servicios registrados.</td></tr>";
                }
                ?>
            </tbody>
        </table>
    </div>

    <!-- Modal de Confirmación -->
    <div id="confirmationModal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closeModal()">&times;</span>
            <h2>¿Estás seguro de eliminar este servicio?</h2>
            <p id="modalMessage"></p>
            <button id="confirmDelete" class="btn-confirm">Sí</button>
            <button class="btn-cancel" onclick="closeModal()">No</button>
        </div>
    </div>

    <script>
        let servicioIdToDelete = null;

        function openModal(servicioId) {
            servicioIdToDelete = servicioId;
            document.getElementById("modalMessage").innerHTML = "Esta acción no se puede deshacer.";
            document.getElementById("confirmationModal").style.display = "block";
        }

        function closeModal() {
            document.getElementById("confirmationModal").style.display = "none";
        }

        document.getElementById("confirmDelete").onclick = function() {
            if (servicioIdToDelete !== null) {
                window.location.href = "eliminar_servicio.php?id=" + servicioIdToDelete;
            }
        }
    </script>
</body>
</html>
