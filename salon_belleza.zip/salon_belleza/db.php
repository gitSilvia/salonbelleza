<?php
// Configuración de la conexión a la base de datos
$host = 'localhost';
$db = 'salon_belleza';
$user = 'root';
$password = '';

// Crear conexión
$conn = new mysqli($host, $user, $password, $db);

// Verificar conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}
?>