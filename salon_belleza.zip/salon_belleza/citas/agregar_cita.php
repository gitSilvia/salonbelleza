<?php
include '../db.php'; // Conexión a la base de datos
include '../menu.php'; // Menú fijo

// Guardar la nueva cita al enviar el formulario
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id_cliente = $_POST['id_cliente'];
    $fecha_cita = $_POST['fecha_cita'];
    $hora = $_POST['hora'];
    $id_servicio = $_POST['id_servicio'];
    $estado = $_POST['estado'];

    // Obtener el precio del servicio seleccionado
    $sql_servicio = "SELECT precio FROM servicios WHERE id_servicio = '$id_servicio'";
    $result_servicio = $conn->query($sql_servicio);
    $monto_total = 0;

    if ($result_servicio->num_rows > 0) {
        $servicio = $result_servicio->fetch_assoc();
        $monto_total = $servicio['precio'];
    }

    // Insertar la cita en la base de datos
    $sql = "INSERT INTO citas (id_cliente, fecha_cita, hora, id_servicio, estado, monto_total) 
            VALUES ('$id_cliente', '$fecha_cita', '$hora', '$id_servicio', '$estado', '$monto_total')";

    if ($conn->query($sql) === TRUE) {
        header('Location: listar_citas.php'); // Redirige a la lista de citas
        exit;
    } else {
        echo "Error: " . $conn->error;
    }
}

// Consulta para obtener la lista de clientes
$clientes = $conn->query("SELECT id_cliente, nombre FROM clientes");

// Consulta para obtener la lista de servicios con sus precios
$servicios = $conn->query("SELECT id_servicio, nombre_servicio, precio FROM servicios");
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agregar Cita</title>
    <!-- Enlace al archivo CSS -->
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <div class="form-container">
        <h1>Agregar Cita</h1>
        <form method="POST" action="">
            <label for="id_cliente">Cliente</label>
            <select name="id_cliente" id="id_cliente" required>
                <option value="">Seleccione un cliente</option>
                <?php while ($cliente = $clientes->fetch_assoc()): ?>
                    <option value="<?php echo $cliente['id_cliente']; ?>">
                        <?php echo $cliente['nombre']; ?>
                    </option>
                <?php endwhile; ?>
            </select>

            <label for="fecha_cita">Fecha</label>
            <input type="date" name="fecha_cita" id="fecha_cita" required>

            <label for="hora">Hora</label>
            <input type="time" name="hora" id="hora" required>

            <label for="id_servicio">Servicio</label>
            <select name="id_servicio" id="id_servicio" required onchange="updateMonto()">
                <option value="">Seleccione un servicio</option>
                <?php while ($servicio = $servicios->fetch_assoc()): ?>
                    <option value="<?php echo $servicio['id_servicio']; ?>" data-precio="<?php echo $servicio['precio']; ?>">
                        <?php echo $servicio['nombre_servicio']; ?>
                    </option>
                <?php endwhile; ?>
            </select>

            <label for="estado">Estado</label>
            <select name="estado" id="estado" required>
                <option value="Pendiente">Pendiente</option>
                <option value="Completado">Completado</option>
                <option value="Cancelado">Cancelado</option>
            </select>

            <label for="monto_total">Monto Total</label>
            <input type="text" id="monto_total" value="0.00" readonly>

            <button type="submit">Agregar Cita</button>
        </form>
    </div>

    <script>
        // Actualizar el monto total cuando se selecciona un servicio
        function updateMonto() {
            var servicioSelect = document.getElementById("id_servicio");
            var selectedOption = servicioSelect.options[servicioSelect.selectedIndex];
            var precio = selectedOption.getAttribute("data-precio");
            document.getElementById("monto_total").value = precio ? precio : "0.00";
        }
    </script>
</body>
</html>