<?php
include '../db.php'; // Conexión a la base de datos

if (isset($_GET['id'])) {
    $id_cita = $_GET['id'];

    // Eliminar la cita de la base de datos
    $sql = "DELETE FROM citas WHERE id_cita = $id_cita";

    if ($conn->query($sql) === TRUE) {
        header('Location: listar_citas.php'); // Redirige después de eliminar
    } else {
        echo "Error al eliminar la cita: " . $conn->error;
    }
}
?>