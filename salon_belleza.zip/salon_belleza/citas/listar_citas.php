<?php
include '../db.php'; // Conexión a la base de datos
include '../menu.php'; // Menú fijo
?>

<body>
    <div class="container">
        <h1>Gestión de Citas</h1>
        <a href="agregar_cita.php" class="add-button">Agregar Cita</a>
        <link rel="stylesheet" href="../css/style.css">
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Cliente</th>
                    <th>Servicio</th>
                    <th>Monto Total</th>
                    <th>Fecha</th>
                    <th>Hora</th>
                    <th>Estado</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php
                // Consulta para obtener todas las citas
                $sql = "SELECT c.id_cita, cl.nombre AS cliente, c.monto_total, s.nombre_servicio AS servicio, c.fecha_cita, c.hora, c.estado 
                        FROM citas c
                        JOIN clientes cl ON c.id_cliente = cl.id_cliente
                        JOIN servicios s ON c.id_servicio = s.id_servicio";
                $result = $conn->query($sql);

                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr>";
                        echo "<td>" . $row['id_cita'] . "</td>";
                        echo "<td>" . $row['cliente'] . "</td>";
                        echo "<td>" . $row['servicio'] . "</td>";
                        echo "<td>" . number_format($row['monto_total'], 2) . "</td>";
                        echo "<td>" . $row['fecha_cita'] . "</td>";
                        echo "<td>" . $row['hora'] . "</td>";
                        echo "<td>" . $row['estado'] . "</td>";
                        echo "<td>";
                        echo "<a href='editar_cita.php?id=" . $row['id_cita'] . "'>Editar</a> | ";
                        echo "<a href='#' onclick='openModal(" . $row['id_cita'] . ")'>Eliminar</a>";
                        echo "</td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='7'>No hay citas registradas.</td></tr>";
                }
                ?>
            </tbody>
        </table>
    </div>

    <!-- Modal de Confirmación -->
    <div id="confirmationModal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closeModal()">&times;</span>
            <h2>¿Estás seguro de eliminar esta cita?</h2>
            <p id="modalMessage"></p>
            <button id="confirmDelete" class="btn-confirm">Sí</button>
            <button class="btn-cancel" onclick="closeModal()">No</button>
        </div>
    </div>

    <script>
        let citaIdToDelete = null;

        function openModal(citaId) {
            citaIdToDelete = citaId;
            document.getElementById("modalMessage").innerHTML = "Esta acción no se puede deshacer.";
            document.getElementById("confirmationModal").style.display = "block";
        }

        function closeModal() {
            document.getElementById("confirmationModal").style.display = "none";
        }

        document.getElementById("confirmDelete").onclick = function() {
            if (citaIdToDelete !== null) {
                window.location.href = "eliminar_cita.php?id=" + citaIdToDelete;
            }
        }
    </script>
</body>
</html>