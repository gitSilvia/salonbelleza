<?php
include '../db.php'; // Conexión a la base de datos
include '../menu.php'; // Menú fijo

// Verificar si se recibe un ID para editar
if (isset($_GET['id'])) {
    $id_cita = $_GET['id'];

    // Consultar los datos de la cita a editar
    $sql = "SELECT * FROM citas WHERE id_cita = $id_cita";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $cita = $result->fetch_assoc();
    } else {
        echo "<script>window.location.href = 'listar_citas.php';</script>";
        exit;
    }
}

// Guardar los cambios al enviar el formulario
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id_cliente = $_POST['id_cliente'];
    $fecha_cita = $_POST['fecha_cita'];
    $hora = $_POST['hora'];
    $id_servicio = $_POST['id_servicio'];
    $estado = $_POST['estado'];

    $sql = "UPDATE citas 
            SET id_cliente = '$id_cliente', fecha_cita = '$fecha_cita', hora = '$hora', 
                id_servicio = '$id_servicio', estado = '$estado' 
            WHERE id_cita = $id_cita";

    if ($conn->query($sql) === TRUE) {
        header('Location: listar_citas.php'); // Redirige directamente a la lista de citas
        exit;
    } else {
        echo "Error: " . $conn->error;
    }
}

// Consulta para obtener la lista de clientes
$clientes = $conn->query("SELECT id_cliente, nombre FROM clientes");

// Consulta para obtener la lista de servicios
$servicios = $conn->query("SELECT id_servicio, nombre_servicio FROM servicios");
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Cita</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <div class="form-container">
        <h1>Editar Cita</h1>
        <form method="POST" action="">
            <label for="id_cliente">Cliente</label>
            <select name="id_cliente" id="id_cliente" required>
                <?php while ($cliente = $clientes->fetch_assoc()): ?>
                    <option value="<?php echo $cliente['id_cliente']; ?>" 
                        <?php echo ($cliente['id_cliente'] == $cita['id_cliente']) ? 'selected' : ''; ?>>
                        <?php echo $cliente['nombre']; ?>
                    </option>
                <?php endwhile; ?>
            </select>

            <label for="fecha_cita">Fecha</label>
            <input type="date" name="fecha_cita" id="fecha_cita" value="<?php echo $cita['fecha_cita']; ?>" required>

            <label for="hora">Hora</label>
            <input type="time" name="hora" id="hora" value="<?php echo $cita['hora']; ?>" required>

            <label for="id_servicio">Servicio</label>
            <select name="id_servicio" id="id_servicio" required>
                <?php while ($servicio = $servicios->fetch_assoc()): ?>
                    <option value="<?php echo $servicio['id_servicio']; ?>" 
                        <?php echo ($servicio['id_servicio'] == $cita['id_servicio']) ? 'selected' : ''; ?>>
                        <?php echo $servicio['nombre_servicio']; ?>
                    </option>
                <?php endwhile; ?>
            </select>

            <label for="estado">Estado</label>
            <select name="estado" id="estado" required>
                <option value="Pendiente" <?php echo ($cita['estado'] == 'Pendiente') ? 'selected' : ''; ?>>Pendiente</option>
                <option value="Completado" <?php echo ($cita['estado'] == 'Completado') ? 'selected' : ''; ?>>Completado</option>
                <option value="Cancelado" <?php echo ($cita['estado'] == 'Cancelado') ? 'selected' : ''; ?>>Cancelado</option>
            </select>

            <button type="submit">Actualizar Cita</button>
        </form>
    </div>
</body>
</html>