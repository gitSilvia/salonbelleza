<?php include 'menu.php'; ?> <!-- Incluir el menú -->
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pantalla Principal - Salón de Belleza</title>
    <style>
        .container {
            text-align: center;
            margin-top: 50px;
            padding: 20px;
        }
        .container h2 {
            font-size: 24px;
            margin-bottom: 10px;
        }
        .container p {
            font-size: 18px;
            margin-bottom: 30px;
        }
    </style>
</head>

</html>
<div id="carouselExampleControls" class="carousel slide" data-bs-ride="carousel">
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="imagen/imagen01.png" class="d-block w-100" alt="Imagen">
    </div>
    </div>
    </div>

